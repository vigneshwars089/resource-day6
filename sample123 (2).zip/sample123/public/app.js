var map = new google.maps.Map(document.getElementById('map_div'), {
  zoom: 1,
  center: new google.maps.LatLng(0,0),
  mapTypeId: google.maps.MapTypeId.ROADMAP
});
var markers = [];
var infowindow = new google.maps.InfoWindow();
var marker, i;
var getloc;
// map.style.visibility='hidden';

function GetGeolocation() {

navigator.geolocation.getCurrentPosition(GetCoords);

}
GetGeolocation();

function GetCoords(position){

  var geocoder = new google.maps.Geocoder();
  //alert(position.coords.latitude);

  //alert(position.coords.longitude);

  //alert(position.coords.accuracy);

 var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
geocoder.geocode({'latLng': latlng}, function(results, status) {
  if (status == google.maps.GeocoderStatus.OK) {
    if (results[1]) {
      map.setZoom(11);
      marker = new google.maps.Marker({
          position: latlng,
          map: map
      });
      infowindow.setContent(results[1].formatted_address);
      infowindow.open(map, marker);
      // var city = findResult(results, "locality");
      // var state = findResult(results, "administrative_area_level_1");
      $('#LocName').html(results[4].formatted_address);
      //alert(results[1].formatted_address);
    }
  } else {
    alert("Geocoder failed due to: " + status);
  }
});

}

//
// if (navigator.geolocation){
//   navigator.geolocation.getCurrentPosition(showPosition);
// }
// else{
//   latitudeAndLongitude.innerHTML="Geolocation is not supported by this browser.";
// }
//
// function showPosition(position){
//     location.latitude=position.coords.latitude;
//     location.longitude=position.coords.longitude;
//     // latitudeAndLongitude.innerHTML="Latitude: " + position.coords.latitude +
//     // "<br>Longitude: " + position.coords.longitude;
//     var geocoder = new google.maps.Geocoder();
//     var latLng = new google.maps.LatLng(location.latitude, location.longitude);
//
//  if (geocoder) {
//     geocoder.geocode({ 'latLng': latLng}, function (results, status) {
//        if (status == google.maps.GeocoderStatus.OK) {
//          console.log(results[0].formatted_address);
//          $('#LocName').html('Address:'+results[0].formatted_address);
//        }
//        else {
//         $('#address').html('Geocoding failed: '+status);
//         console.log("Geocoding failed: " + status);
//        }
//     }); //geocoder.geocode()
//   }
// }


// function currentLocation(){
//   GetGeolocation();
// document.getElementById('showCard').style.display='none';
//
//   // document.getElementById('regions_div').style.display='none';
// document.getElementById('chart_div').style.display='none';
// document.getElementById('map_div').style.display='block';
// document.getElementById('selectedName').style.display='none';
// document.getElementById('currentName').style.display='block';
// document.getElementById('head').style.display='none';
// document.getElementById('ChooseLoc').style.display='none';
// document.getElementById('CurrentLoc').style.display='block';
//
// document.getElementById('changeIcon').style.visibility ="visible";
// document.getElementById('currentIcon').style.visibility ="hidden";
//
// $("#LocName").empty();
//
//     if (navigator.geolocation)
//     {
//       navigator.geolocation.getCurrentPosition(function(position) {
//           var pos = {
//             lat: position.coords.latitude,
//             lng: position.coords.longitude
//           };
//
//           infowindow.setPosition(pos);
//
//           var map = new google.maps.Map(document.getElementById('map_div'), {
//             zoom: 6,
//             center: new google.maps.LatLng(position.coords.latitude,position.coords.longitude),
//             mapTypeId: google.maps.MapTypeId.ROADMAP
//           });
//
//           marker = new google.maps.Marker({
//             map: map,
//             draggable: false,
//             animation: google.maps.Animation.DROP,
//             position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
//           });
//           google.maps.event.addListener(marker, 'click', (function(marker, i) {
//             return function() {
//               infowindow.setContent("You are here");
//               infowindow.open(map, marker);
//             }
//           })(marker, i));
//
//           google.maps.event.addListener(marker, 'click', function(event) {
//             geocoder.geocode({
//               'latLng': event.latLng
//             }, function(results, status) {
//               if (status == google.maps.GeocoderStatus.OK) {
//                 if (results[0]) {
//                   // alert(results[0].formatted_address);
//                       infowindow.setContent(results[0].formatted_address);
//                       infowindow.open(map, marker);
//                 }
//               }
//             });
//           });
//
//           google.maps.event.addListener(marker, 'mouseout', (function(marker, i) {
//             return function() {
//               infowindow.close(map, marker);
//             }
//           })(marker, i));
//           //marker.addListener('click', toggleBounce);
//           // infowindow.open(map);
//           map.setCenter(pos);
//           }, function() {
//             handleLocationError(true, infowindow, map.getCenter());
//       }, function(geoOptions)
//       {
//          enableHighAccuracy: true
//       });
//     }
//     else
//     {
//       // Browser doesn't support Geolocation
//       handleLocationError(false, infowindow, map.getCenter());
//       return 5;
//     }
//   }

function ChangeLocation() {
  document.getElementById('showCard').style.display='none';

  document.getElementById('chart_div').style.display='none';
  document.getElementById('map_div').style.display='block';

  document.getElementById('currentName').style.display='none';
  document.getElementById('selectedName').style.display='block';

  document.getElementById('head').style.display='none';
  document.getElementById('CurrentLoc').style.display='none';
  document.getElementById('ChooseLoc').style.display='block';

  document.getElementById('changeIcon').style.visibility ="hidden";
  document.getElementById('currentIcon').style.visibility ="visible";


  $("#LocName").empty();

  // var map = new google.maps.Map(document.getElementById('map_div'), {
  //   center: {lat: -33.866, lng: 151.196},
  //   zoom: 15
  // });
  var map = new google.maps.Map(document.getElementById('map_div'), {
    zoom: 1,
    center: new google.maps.LatLng(0,0),
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  var geocoder = new google.maps.Geocoder();

  $.getJSON('public/Map_Data/Location_Data.json', function(jsonObj){
        // console.log(jsonObj);
        // Global_Map_Data = jsonObj;
        // for(var k in jsonObj)
        // {
        //   Global_Map_Data[k]=jsonObj[k];
        // }
        // // console.log(Global_Map_Data);
        // global_data_info();
        var locations = jsonObj['points'];

        var markers = locations.map(function(location, i) {
             return new google.maps.Marker({
               position: new google.maps.LatLng(locations[i][1], locations[i][2]),
               // title: locations[]
               icon: {
                       url: 'images/Cognizant_pin.png'
                     },
               title: (locations[i][0]).toString(),
               map: map
             });
           });

         // Add a marker clusterer to manage the markers.
        //  markerCluster = new MarkerClusterer(map, markers, {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});

        // To identify the location of marker cluster
        //  google.maps.event.addDomListener(markerCluster, 'clusterclick', function(cluster){
        //    var m = cluster.getMarkers();
        //    var titles = "";
        //     // for(var i = 0; i < m.length; i++) {
        //         titles = m[0].getTitle();
        //     // }
        //     // console.log(titles);
        //     titles.trim();
        //     for (var i = 0; i < locations.length; i++) {
        //       // console.log("Hi i am inside the for loop");
        //       // var json_obj = locations[i];
        //       // json_obj = json_obj.split(',');
        //       if(locations[i][0] == titles)
        //       {
        //         var obj_record = locations[i][9];
        //         obj_record = obj_record.split(',');
        //         // console.log(obj_record[obj_record.length - 1]);
        //         card_details_info(obj_record);
        //       }
        //     }
         //
        //  });

        for (i = 0; i < locations.length; i++){
        // marker = new google.maps.Marker({
        //       position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        //       // title: locations[]
        //       icon: {
        //               url: '/images/Cognizant_pin.png'
        //             },
        //       title: (locations[i][0]).toString(),
        //       map: map
        // });
        google.maps.event.addListener(markers[i], 'click', (function(marker, i) {
          return function() {
            // infowindow.setContent(locations[i][0]);
            // infowindow.open(map, markers[i]);
          //  calculator_funx(locations[i][0]);
          $('#LocName').html(locations[i][0]);
          }
        })(marker, i));
        google.maps.event.addListener(markers[i], 'mouseout', (function(marker, i) {
          return function() {
            infowindow.close(map, markers[i]);
          }
        })(marker, i));


      }
    });









  // var infowindow = new google.maps.InfoWindow();
  // var service = new google.maps.places.PlacesService(map);
  //
  // service.getDetails({
  //   placeId: 'ChIJN1t_tDeuEmsRUsoyG83frY4'
  // }, function(place, status) {
  //   if (status === google.maps.places.PlacesServiceStatus.OK) {
  //     var marker = new google.maps.Marker({
  //       map: map,
  //       position: place.geometry.location
  //     });
  //     google.maps.event.addListener(marker, 'click', function() {
  //       infowindow.setContent('<div><strong>' + place.name + '</strong><br>' +
  //         'Place ID: ' + place.place_id + '<br>' +
  //         place.formatted_address + '</div>');
  //       infowindow.open(map, this);
  //     });
  //   }
  // });
}



  function SearchLocation() {
    if(getloc!=null)

    // document.getElementById('regions_div').style.display='none';
  document.getElementById('map_div').style.display='block';
   //console.log("Hi");
      geocoder = new google.maps.Geocoder();

    //  var latlng = new google.maps.LatLng(-34.397, 150.644);
      var mapOptions = {
          zoom: 3,
          // center: latlng
      };

      map = new google.maps.Map(document.getElementById("map_div"), mapOptions);

      // Call the codeAddress function (once) when the map is idle (ready)
      google.maps.event.addListenerOnce(map, 'idle', codeAddress);
  }

  function codeAddress() {

      // Define address to center map to
      var address = getloc;

      geocoder.geocode({
          'address': address
      }, function (results, status) {

          if (status == google.maps.GeocoderStatus.OK) {

              // Center map on location
              map.setCenter(results[0].geometry.location);

              // Add marker on location
              var marker = new google.maps.Marker({
                  map: map,
                  position: results[0].geometry.location
              });

          } else {

              alert("Geocode was not successful for the following reason: " + status);
          }
      });
  }

function ViewChart(){
 document.getElementById('showCard').style.display='block';
 document.getElementById('map_div').style.display='none';
 document.getElementById('chart_div').style.display='block';
 //GetGeolocation();
 document.getElementById('Half-view').style.display='block';
 document.getElementById('Resourcetbl').style.display='none';


document.getElementById('searchbox').style.display='none';
document.getElementById('main-bar').style.display='block';

 // document.getElementById('currentName').style.display='block';
 // document.getElementById('selectedName').style.display='none';

   document.getElementById('CurrentLoc').style.display='none';
   document.getElementById('ChooseLoc').style.display='none';
   document.getElementById('head').style.display='block';

   document.getElementById('changeIcon').style.visibility ="visible";
   document.getElementById('currentIcon').style.visibility ="visible";

}






//to view the search box
function ViewSearch(){
  if(document.getElementById('searchbox').style.display=='block')
 document.getElementById('searchbox').style.display='none';

 else
 document.getElementById('searchbox').style.display='block';
 document.getElementById('map_div').style.display='none';
 document.getElementById('chart_div').style.display='none';
 document.getElementById('CurrentLoc').style.display='none';
 document.getElementById('ChooseLoc').style.display='none';
 document.getElementById('head').style.display='none';
 document.getElementById('showCard').style.display='none';
 document.getElementById('main-bar').style.display='none';



}

function viewfilters(){
  if( document.getElementById('filters').style.display=='none')
  {
  document.getElementById('result').style.display='none';
  document.getElementById('filters').style.display='block';
  document.getElementById('newtool').style.color='#37c8ef';
  // document.getElementById("tab1").style.marginTop = "24px";

}
else
{
  document.getElementById('result').style.display='block';
  document.getElementById('filters').style.display='none';
  document.getElementById('newtool').style.color='white';
}
}

function ResourceView(){
  // if( document.getElementById('Resourcetbl').style.display=='none')
  // {
  document.getElementById('Resourcetbl').style.display='block';
  document.getElementById('Half-view').style.display='none';
  document.getElementById('showCard').style.display='none';

  // document.getElementById("tab1").style.marginTop = "24px";

// }
// else
// {
//   document.getElementById('result').style.display='block';
//   document.getElementById('filters').style.display='none';
//   document.getElementById('newtool').style.color='white';
// }
}



//--code to load the geochart
// google.charts.load('current', {'packages':['geochart']});
//      google.charts.setOnLoadCallback(drawRegionsMap);
//
//      function drawRegionsMap() {
//
//       var data= null;
//
//
//
//     //    var options = {
//     //  colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
//     //    };
//
//       //  var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
//
//        $.getJSON("./ChartInput.json", function(jsonObj){
//              console.log(jsonObj.GeoData);
//           var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
//           // var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
//              console.log(data);
//             var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
//              var options = {
//
//             colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
//              };
//              function selectHandler() {
//                      var selectedItem = chart.getSelection()[0];
//                      if (selectedItem) {
//                        var topping = data.getValue(selectedItem.row, 1);
//                        getloc=data.getValue(selectedItem.row, 0);
//                     //   alert('The user selected ' + topping);
//                        document.getElementById("myLink").innerHTML=topping;
//                      }
//                    }
//                     google.visualization.events.addListener(chart, 'select', selectHandler);
//              chart.draw(data, options);
//           //    setInterval(function() {
//           // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //        chart.draw(data1, options);
//           //     }, 5000);
//           //     setInterval(function() {
//           //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //         chart.draw(data, options);
//           //      }, 2000);
//
//          //    var locations = jsonObj['points'];
//
//            //  for (i = 0; i < locations.length; i++) {
//            //  marker = new google.maps.Marker({
//              //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
//                    // title: locations[]
//                //    icon: {
//                  //          url: '/images_map/map_pin.png'
//                    //      },
//                  //  title: (locations[i][0]).toString(),
//              //      map: map
//              });
//       // chart.draw(data, options);
//       //  setInterval(function() {
//       //    data.setValue(0, 1, 140 + Math.round(60 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(1, 1, 140 + Math.round(60 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(2, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(4, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//       //  setInterval(function() {
//       //    data.setValue(5, 1, 160 + Math.round(20 * Math.random()));
//       //    chart.draw(data, options);
//       //  }, 1300);
//      }
//
//
// //---code to load the stackedChart
//
//      google.charts.load('current', {packages: ['corechart', 'bar']});
// google.charts.setOnLoadCallback(drawStacked);
//
// function drawStacked() {
//       // var data = google.visualization.arrayToDataTable([
//       //   ['City', '2010 Population', '2000 Population'],
//       //   ['New York City, NY', 8175000, 8008000],
//       //   ['Los Angeles, CA', 3792000, 3694000],
//       //   ['Chicago, IL', 2695000, 2896000],
//       //   ['Houston, TX', 2099000, 1953000],
//       //   ['Philadelphia, PA', 1526000, 1517000]
//       // ]);
//
//       var options1 = {
//       //  title: 'Population of Largest U.S. Cities',
//         chartArea: {width: '30%'},
//         isStacked: true,
//         hAxis: {
//           title: 'Country',
//           minValue: 0,
//           width:"200px",
//           slantedTextAngle:70
//         },
//         width:'600px',
//         vAxis: {
//           title: 'Counts',
//           height:"500px"
//         },
//         width: 350,
//                 height: 350,
//                 bar: {groupWidth: "50%"},
//                  bars: 'vertical-align',
//                  animation: {
//          duration: 1000,
//          easing: 'in'
//      }
//               //  legend: { position: "none" }
//       };
//
//       var data= null;
//
//
//
//     //   var options = {};
//
//     //   var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
//
//        $.getJSON("./ChartInput.json", function(jsonObj){
//              console.log(jsonObj.barData);
//           var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
//           var data2 = google.visualization.arrayToDataTable(jsonObj['barData1']);
//           //  var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
//              console.log(data);
//               var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
//
//
//              chart.draw(data1, options1);
//                 setInterval(function() {
//              //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//                     chart.draw(data1, options1);
//                  }, 2000);
//                  setInterval(function() {
//               //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//                      chart.draw(data2, options1);
//                   }, 4000);
//           //    setInterval(function() {
//           // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //        chart.draw(data1, options);
//           //     }, 5000);
//           //     setInterval(function() {
//           //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
//           //         chart.draw(data, options);
//           //      }, 2000);
//
//          //    var locations = jsonObj['points'];
//
//            //  for (i = 0; i < locations.length; i++) {
//            //  marker = new google.maps.Marker({
//              //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
//                    // title: locations[]
//                //    icon: {
//                  //          url: '/images_map/map_pin.png'
//                    //      },
//                  //  title: (locations[i][0]).toString(),
//              //      map: map
//              });
//
//     //  var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
//     //  chart.draw(data, options);
//     }





    //--function to load the current map location
